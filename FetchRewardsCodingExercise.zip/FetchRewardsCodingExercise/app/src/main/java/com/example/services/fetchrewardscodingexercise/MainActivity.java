//Bryan Gutierrez
package com.example.services.fetchrewardscodingexercise;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainActivity extends AppCompatActivity { private TextView textResults;
    private ListView list;
    private RequestQueue mRequest;
    private List<JSONObject> jsonValues = new ArrayList<JSONObject>();
    private JSONArray sorted= new JSONArray();
    private Button dataButton;
    private EditText filter;
    private Button filterButton;
    private ArrayAdapter arrayAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //initiate buttons,text fields, and list
        setContentView(R.layout.activity_main);
        list = findViewById(R.id.data);
        dataButton = findViewById(R.id.getData);
        filter = findViewById(R.id.filter);
        filterButton = findViewById(R.id.filterButton);
        filterButton.setVisibility(View.INVISIBLE);
        filter.setVisibility(View.INVISIBLE);
        mRequest = Volley.newRequestQueue(this); //Use Volley to get JSON data

        //Button to parse JSON data from web
        dataButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getData();
                filterButton.setVisibility(View.VISIBLE);
                filter.setVisibility(View.VISIBLE);

            }
        });
        //Button to filter data after its been parsed
        filterButton.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                arrayAdapter.clear();
                arrayAdapter.notifyDataSetChanged();
                makeList(Integer.parseInt(filter.getText().toString()));
            }
        });

    }

    private void getData(){
        String url = "https://fetch-hiring.s3.amazonaws.com/hiring.json"; //site given
        JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        jsonValues = new ArrayList<JSONObject>(); //create new ArrayList to hold JSONArray from website(response)
                        for (int i = 0; i < response.length(); i++) {
                            try {
                                if(!response.getJSONObject(i).isNull("name") && !response.getJSONObject(i).getString("name").isEmpty())// == JSONObject.NULL)
                                    jsonValues.add(response.getJSONObject(i));

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                        //Sort data by listID then name
                        Collections.sort(jsonValues, new Comparator<JSONObject>() {
                            //make two constant variables for sorting
                            private static final String FIRST_SORT = "listId";
                            private static final String SECOND_SORT = "name";
                            @Override
                            public int compare(JSONObject o1, JSONObject o2) {
                                String compareName1 = new String();
                                String compareName2 = new String();
                                Integer compare = null;
                                try {

                                    Integer compareID1 = (Integer)o1.get(FIRST_SORT);
                                    Integer compareID2 = (Integer)o2.get(FIRST_SORT);
                                    compare = compareID1.compareTo(compareID2);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                                    if (compare != 0) {
                                        return compare;
                                    }

                                try {
                                        compareName1 = (String) o1.get(SECOND_SORT);
                                        compareName2 = (String) o2.get(SECOND_SORT);

                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                                //extra comparison needed ex: 24 > 248 using compareTo()
                                if(compareName1.length() < compareName2.length())
                                    return -1;
                                else if(compareName1.length() > compareName2.length())
                                    return 1;
                                else
                                    return compareName1.compareTo(compareName2);


                            }
                        });
                        makeList(0); //add to ListView
                        dataButton.setVisibility(View.INVISIBLE); //dataButton no longer needed
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });
        mRequest.add(request);
    }

    private void makeList(int filter){

        ArrayList<String> dataStringList = new ArrayList<>();
        sorted = new JSONArray();
        //add values to sorted from jsonValues with filter
        for (int i = 0; i < jsonValues.size(); i++) {
            try {
                if(filter != 0 && jsonValues.get(i).getInt("listId") == filter )
                    sorted.put(jsonValues.get(i));
                else if(filter == 0)
                    sorted.put(jsonValues.get(i));
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        try {
            //add values from sorted JSONArray to string arrayList
            for(int i = 0; i < sorted.length();i++)
            {
                JSONObject item = sorted.getJSONObject(i);

                int id = item.getInt("id");
                int listID = item.getInt("listId");
                String name = item.getString("name");
                if(filter == 0 || filter == listID)
                    dataStringList.add("List ID: " + listID + ", ID: " + id + ", Name: " + name);

            }
        }
        catch (JSONException e) {
            e.printStackTrace();
        }
        //apply to UI
        arrayAdapter = new ArrayAdapter(this,android.R.layout.simple_list_item_1,dataStringList);
        arrayAdapter.notifyDataSetChanged();
        list.setAdapter(arrayAdapter);
    }
}